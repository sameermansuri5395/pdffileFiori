sap.ui.define([
		"sap/ui/core/UIComponent"
	],
	function(oComponent) {

		return oComponent.extend("ucic.sd.so.Component", {
	
			metadata: {
				manifest: "json"
			},
			init: function() {
  
				 oComponent.prototype.init.apply(this, arguments);
  	debugger
					// sap.ui.require([
					// 	"ucic/sd/so/libs/pdfjs/build/pdf"
					// ], function() {
					// 	// PDF.js is loaded
					// });
					// debugger
					var oRouter = this.getRouter();
					oRouter.initialize();
				}
				// createContent: function() {

			// },

			// destroy: function() {

			

		});

	});